#include "Block.h"

#include <Arduino.h>

#include "SensorKontakt.h"
#include "SensorStrom.h"
#include "mega2_debug.h"

// Optional: Event-Logging pro Block (nur Edge, nicht "polling-spam")
#ifndef MEGA2_DEBUG_BLOCK_EVENTS
#define MEGA2_DEBUG_BLOCK_EVENTS 0
#endif

// Entprell-/Stabilitätsfenster (für "wirklich frei")
static constexpr uint32_t STABLE_FREE_MS    = 500;
static constexpr uint32_t STABLE_SIGNAL_MS  = 50;

#if MEGA2_DEBUG && MEGA2_DEBUG_BLOCK_EVENTS
static inline void dbgPrintBlockEvent(uint8_t id, const __FlashStringHelper* what, bool active)
{
    DBG_PRINT(F("[B"));
    DBG_PRINT(id);
    DBG_PRINT(F("] "));
    DBG_PRINT(what);
    DBG_PRINT(F(" "));
    DBG_PRINTLN(active ? F("AKTIV") : F("frei"));
}
#endif

Block::Block(uint8_t id,
             SensorKontakt* kontakt1,
             SensorStrom* strom,
             SensorKontakt* kontakt2,
             SensorKontakt* kontakt3)
: m_id(id)
, m_kontakt1(kontakt1)
, m_strom(strom)
, m_kontakt2(kontakt2)
, m_kontakt3(kontakt3)
, m_kontaktAktiv(false)
, m_stromAktiv(false)
, m_lastKontaktHighMs(0)
, m_lastStromHighMs(0)
, m_lastFreeMs(0)
, m_besetzt(false)
{
}

static inline bool kontaktOcc(SensorKontakt* k)
{
    // SensorKontakt arbeitet mit INPUT_PULLUP; raw() ist im Projekt als "belegt/aktiv" definiert.
    return k ? k->raw() : false;
}

void Block::begin()
{
    // Initialzustand aus den Sensoren lesen
    const bool nowKontakt =
        kontaktOcc(m_kontakt1) ||
        kontaktOcc(m_kontakt2) ||
        kontaktOcc(m_kontakt3);

    const bool nowStrom = (m_strom ? m_strom->isActive() : false);

    m_kontaktAktiv = nowKontakt;
    m_stromAktiv   = nowStrom;
    m_besetzt      = (nowKontakt || nowStrom);

    const uint32_t now = millis();
    m_lastKontaktHighMs = nowKontakt ? 0 : now;
    m_lastStromHighMs   = nowStrom   ? 0 : now;
    m_lastFreeMs        = m_besetzt  ? 0 : now;
}

void Block::update(uint32_t nowMs)
{
    const bool nowKontakt =
        kontaktOcc(m_kontakt1) ||
        kontaktOcc(m_kontakt2) ||
        kontaktOcc(m_kontakt3);

    const bool nowStrom = (m_strom ? m_strom->isActive() : false);

    // Kontakt-Edge
    if (nowKontakt != m_kontaktAktiv)
    {
        m_kontaktAktiv = nowKontakt;
        if (!nowKontakt) m_lastKontaktHighMs = nowMs;
        else             m_lastKontaktHighMs = 0;

    #if MEGA2_DEBUG && MEGA2_DEBUG_BLOCK_EVENTS
        dbgPrintBlockEvent(m_id, F("Kontakt"), nowKontakt);
    #endif
    }

    // Strom-Edge
    if (nowStrom != m_stromAktiv)
    {
        m_stromAktiv = nowStrom;
        if (!nowStrom) m_lastStromHighMs = nowMs;
        else           m_lastStromHighMs = 0;

    #if MEGA2_DEBUG && MEGA2_DEBUG_BLOCK_EVENTS
        dbgPrintBlockEvent(m_id, F("Strom"), nowStrom);
    #endif
    }

    // Gesamtzustand
    const bool nowBesetzt = (m_kontaktAktiv || m_stromAktiv);
    if (nowBesetzt != m_besetzt)
    {
        m_besetzt = nowBesetzt;

        if (!m_besetzt)
            m_lastFreeMs = nowMs;
        else
            m_lastFreeMs = 0;

    #if MEGA2_DEBUG && MEGA2_DEBUG_BLOCK_EVENTS
        dbgPrintBlockEvent(m_id, F("Block"), m_besetzt);
    #endif
    }
}

bool Block::isReallyFree(uint32_t nowMs) const
{
    if (m_besetzt) return false;

    // Wenn nie gesetzt (z.B. direkt nach Boot), nehmen wir "frei" an
    if (m_lastFreeMs == 0) return true;

    if ((nowMs - m_lastFreeMs) < STABLE_FREE_MS)
        return false;

    // Optional: extra Stabilität pro Signal (falls Sensor-Prellen)
    if (m_lastKontaktHighMs != 0 && (nowMs - m_lastKontaktHighMs) < STABLE_SIGNAL_MS)
        return false;

    if (m_lastStromHighMs != 0 && (nowMs - m_lastStromHighMs) < STABLE_SIGNAL_MS)
        return false;

    return true;
}
