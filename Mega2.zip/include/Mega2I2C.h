#pragma once
#include <Arduino.h>
#include <Wire.h>
#include "i2c_packets.h"

class Mega2I2C
{
public:
    void begin();
    void update(uint32_t now);

    void sendAnalogSample(uint16_t v1, uint16_t v2);

private:
    uint32_t m_lastSend = 0;

    void sendStatePacket();
};
