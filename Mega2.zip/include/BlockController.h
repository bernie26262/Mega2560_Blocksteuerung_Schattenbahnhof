#pragma once
#include <Arduino.h>
#include "Block.h"

constexpr uint8_t BLOCK_COUNT = 10;

class BlockController {
public:
    BlockController(Block** blocks);

    void begin();
    void update(uint32_t now);

    uint8_t countZuegeOben() const;

    bool canFahren_3_nach_4() const;
    bool canFahren_4_nach_oben() const;

    bool m_trafoObenOn  = true;
    bool m_trafoUntenOn = true;

private:
    Block** m_blocks;
};
