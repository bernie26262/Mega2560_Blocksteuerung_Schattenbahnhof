// placeholder#pragma once
#include <Arduino.h>

// I2C-Adresse des Mega2
#define MEGA2_I2C_ADDRESS  0x12

// I2C-Adresse des ESP32 (Empfänger)
#define ESP32_I2C_ADDRESS  0x09

// Pakettypen
enum I2CPacketType : uint8_t
{
    PKT_MEGA2_STATE = 1,     // Mega2 → ESP32 sendet Status
    PKT_MEGA2_ANALOG = 2,    // Mega2 → ESP32 sendet analoge Werte
    PKT_MEGA2_COMMAND = 3,   // ESP32 → Mega2 sendet Befehle
    PKT_MEGA2_ACK = 4        // Bestätigung
};
