// placeholder#pragma once
#include <Arduino.h>
#include "Block.h"
#include "Weiche.h"
#include "BlockController.h"
#include "PowerControlPins.h"
#include "SensorKontakt.h"

class ShadowYardController
{
public:
    ShadowYardController(
        Block** blocks,
        Weiche** weichen,
        BlockController* controller,
        PowerControlPins* power,
        SensorKontakt* nothaltKontakt
    );

    void begin();
    void update(uint32_t now);

private:
    Block** m_blocks = nullptr;
    Weiche** m_weichen = nullptr;

    BlockController* m_ctrl = nullptr;
    PowerControlPins* m_power = nullptr;
    SensorKontakt*    m_nothalt = nullptr;

    uint32_t m_lastAction = 0;
};
