#pragma once
#include <Arduino.h>

// Abstrakte Basisklasse für Stromsteuerung im SBhf-Bereich.
// ShadowYardController arbeitet nur gegen diese Schnittstelle,
// NICHT gegen Mega2-spezifische Pins.

class PowerControl {
public:
    virtual ~PowerControl() {}

    // Block 5 -> Schattenbahnhof
    virtual void setBlock5ToSBhf(bool on) = 0;

    // SBhf Gleise 1 bis 3
    virtual void setSbhfGleis(uint8_t gleis, bool on) = 0;

    // Nothalt-Gleis
    virtual void setNothalt(bool on) = 0;
};
