#include <Arduino.h>
#include "mega2_pins.h"

#include "Block.h"
#include "BlockController.h"
#include "Weiche.h"

#include "PulseSensor.h"
#include "PowerControl.h"
#include "Mega2PowerControl.h"

#include "ShadowYardController.h"
#include "Mega2I2C.h"  // megaI2C_begin(), megaI2C_update()

// ============================================================================
// GLOBALE OBJEKTE
// ============================================================================

// --------------------- BLOCKS --------------------------
Block* g_blocks[16];           
BlockController g_bc(g_blocks);

// --------------------- POWER ---------------------------
Mega2PowerControl g_power;

// --------------------- SCHALTGLEISE S11–S16 ------------
PulseSensor g_s11(PIN_SCHALTGLEIS_S11);
PulseSensor g_s12(PIN_SCHALTGLEIS_S12);
PulseSensor g_s13(PIN_SCHALTGLEIS_S13);
PulseSensor g_s14(PIN_SCHALTGLEIS_S14);
PulseSensor g_s15(PIN_SCHALTGLEIS_S15);
PulseSensor g_s16(PIN_SCHALTGLEIS_S16);

// -------------------- WEICHEN-Rückmelder --------------
SensorKontakt sensorW12(PIN_W12_RM_ABBIEG);
SensorKontakt sensorW13(PIN_W13_RM_ABBIEG);
SensorKontakt sensorW14(PIN_W14_RM_ABBIEG);
SensorKontakt sensorW15(PIN_W15_RM_ABBIEG);

// --------------------- WEICHEN -------------------------
Weiche w12(12, PIN_W12_GERADE, PIN_W12_ABBIEGEN, &sensorW12);
Weiche w13(13, PIN_W13_GERADE, PIN_W13_ABBIEGEN, &sensorW13);
Weiche w14(14, PIN_W14_GERADE, PIN_W14_ABBIEGEN, &sensorW14);
Weiche w15(15, PIN_W15_GERADE, PIN_W15_ABBIEGEN, &sensorW15);

// Array für SBhf + Payload
Weiche* g_weichen[4] = { &w12, &w13, &w14, &w15 };

// --------------------- SCHATTENBAHNHOF -----------------
ShadowYardController g_sbhf(
    &g_bc,
    g_weichen[0],   // W12
    g_weichen[1],   // W13
    g_weichen[2],   // W14
    g_weichen[3],   // W15
    &g_power,
    &g_s11, &g_s12, &g_s13, &g_s14, &g_s15, &g_s16
);

// ============================================================================
// TIMER SYSTEM
// ============================================================================

uint32_t lastBlockUpdate = 0;
uint32_t lastSbhfUpdate  = 0;
uint32_t lastI2CUpdate   = 0;
uint32_t lastSafetyCheck = 0;

static const uint32_t BLOCK_UPDATE_INTERVAL = 20;   // 50 Hz
static const uint32_t SBHF_UPDATE_INTERVAL  = 10;   // 100 Hz
static const uint32_t I2C_SEND_INTERVAL     = 100;  // 10 Hz
static const uint32_t SAFETY_INTERVAL       = 50;   // 20 Hz

// ============================================================================
// SETUP
// ============================================================================
void setup()
{
    Serial.begin(115200);

    Serial.println(F("\n=== Mega2 Schattenbahnhof startet ==="));

    // Blocks initialisieren (falls vorhanden)
    for (int i = 0; i < 16; i++)
        if (g_blocks[i])
            g_blocks[i]->begin();

    g_bc.begin();
    g_power.begin();
    g_s11.begin(); g_s12.begin(); g_s13.begin();
    g_s14.begin(); g_s15.begin(); g_s16.begin();

    w12.begin();
    w13.begin();
    w14.begin();
    w15.begin();

    g_sbhf.begin();

    pinMode(PIN_DATA_READY_M2, OUTPUT);
    digitalWrite(PIN_DATA_READY_M2, LOW);

    megaI2C_begin();
}

// ============================================================================
// LOOP — Timerbasierte Task Engine
// ============================================================================
void loop()
{
    uint32_t now = millis();

    if (now - lastBlockUpdate >= BLOCK_UPDATE_INTERVAL) {
        lastBlockUpdate = now;
        g_bc.update(now);
    }

    if (now - lastSbhfUpdate >= SBHF_UPDATE_INTERVAL) {
        lastSbhfUpdate = now;
        g_sbhf.update(now);
    }

    if (now - lastSafetyCheck >= SAFETY_INTERVAL) {
        lastSafetyCheck = now;
        // TODO: Safety engine
    }

    if (now - lastI2CUpdate >= I2C_SEND_INTERVAL) {
        lastI2CUpdate = now;

        megaI2C_update();

        digitalWrite(PIN_DATA_READY_M2, HIGH);
        delayMicroseconds(200);
        digitalWrite(PIN_DATA_READY_M2, LOW);
    }
}
