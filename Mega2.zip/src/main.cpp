#include <Arduino.h>
#include <Wire.h>

#include "config.h"
#include "debug.h"

#include "BlockController.h"
#include "ShadowYardController.h"
#include "PowerControlPins.h"
#include "Mega2I2C.h"

#include "core/proto_mega2.h"

// ---------------------------------------------------------------------------------------------------------------------
// OBJEKTE
// ---------------------------------------------------------------------------------------------------------------------

PowerControlPins      g_power;
BlockController*      g_blockController = nullptr;
ShadowYardController* g_sbhf = nullptr;

// ---------------------------------------------------------------------------------------------------------------------
// PROTOKOLL / PAYLOAD
// ---------------------------------------------------------------------------------------------------------------------

Mega2StatusPayload g_payload;
volatile bool g_payloadDirty = false;
bool g_payloadInitialized = false;

uint16_t g_lastBlockBits      = 0;
uint16_t g_lastKontaktMainBits= 0;
uint16_t g_lastBhf1Bits       = 0;
uint16_t g_lastBhf2Bits       = 0;
uint16_t g_lastSBhfBits       = 0;
uint16_t g_lastWeichenIstBits = 0;
uint16_t g_lastWeichenSollBits= 0;

unsigned long g_lastUptimeUpdate = 0;
uint16_t g_bootId = 0;

// ---------------------------------------------------------------------------------------------------------------------
// SETUP
// ---------------------------------------------------------------------------------------------------------------------

void setup()
{
    Serial.begin(115200);
    delay(300);

    Serial.println(F("=== Mega2 Start ==="));

    // Kontrolleure
    g_blockController = new BlockController();
    g_sbhf            = new ShadowYardController();

    // I2C
    megaI2C_begin();

    // Payload initialisieren
    randomSeed(analogRead(0));
    g_bootId                    = (uint16_t)random(1, 65535);

    g_payload.bootId            = g_bootId;
    g_payload.updateCounter     = 0;
    g_payload.statusFlags       = 0;
    g_payload.errorFlags        = ERR_NONE;
    g_payload.warnFlags         = WARN_NONE;
    g_payload.powerState        = g_power.state();

    g_payload.blockBits         = 0;
    g_payload.blockKontaktMainBits = 0;
    g_payload.blockKontaktBhf1Bits = 0;
    g_payload.blockKontaktBhf2Bits = 0;
    g_payload.sbhfBits          = 0;

    g_payload.weichenIstBits    = 0;
    g_payload.weichenSollBits   = 0;

    g_payload.trafoOben_mV      = 0;
    g_payload.trafoUnten_mV     = 0;

    g_payloadInitialized        = false;
    g_payloadDirty              = false;
}

// ---------------------------------------------------------------------------------------------------------------------
// LOOP
// ---------------------------------------------------------------------------------------------------------------------

void loop()
{
    unsigned long now = millis();

    // ---------------------------
    // Update Logik
    // ---------------------------
    g_blockController->update(now);
    g_sbhf->update(now);

    // ---------------------------
    // PAYLOAD FÜLLEN
    // ---------------------------

    // Uptime
    if (now - g_lastUptimeUpdate >= 100) {
        g_payload.uptimeDiv100 = now / 100;
        g_lastUptimeUpdate = now;
    }

    // ---------------------------
    // Blockbelegung + Ströme
    // ---------------------------
    uint16_t blockBits = 0;
    uint16_t mainBits  = 0;
    uint16_t bhf1Bits  = 0;
    uint16_t bhf2Bits  = 0;

    for (uint8_t i = 0; i < MEGA2_MAX_BLOCKS; i++) {

        // Block besetzt über Strom (Hauptflag)
        if (g_blocks[i] && g_blocks[i]->besetzt())
            blockBits |= (1u << i);

        // Stromwerte
        g_payload.blockCurrent_mA[i] = g_blocks[i] ? g_blocks[i]->strom_mA() : 0;

        // Hauptkontakt
        if (g_blocks[i] && g_blocks[i]->mainKontakt && g_blocks[i]->mainKontakt->isOccupied())
            mainBits |= (1u << i);

        // Bahnhofskontakt 1
        if (g_blocks[i] && g_blocks[i]->bhf1 && g_blocks[i]->bhf1->isOccupied())
            bhf1Bits |= (1u << i);

        // Bahnhofskontakt 2
        if (g_blocks[i] && g_blocks[i]->bhf2 && g_blocks[i]->bhf2->isOccupied())
            bhf2Bits |= (1u << i);
    }

    g_payload.blockBits            = blockBits;
    g_payload.blockKontaktMainBits = mainBits;
    g_payload.blockKontaktBhf1Bits = bhf1Bits;
    g_payload.blockKontaktBhf2Bits = bhf2Bits;

    // ---------------------------
    // Schattenbahnhof
    // ---------------------------
    uint16_t sbBits = 0;
    for (uint8_t i = 0; i < MEGA2_MAX_SBH_GLEISE; i++) {
        if (g_sbhf->gleisBelegt(i))
            sbBits |= (1u << i);
    }
    g_payload.sbhfBits = sbBits;

    g_payload.sbhfState     = g_sbhf->state();
    g_payload.sbhfSollGleis = g_sbhf->sollGleis();
    g_payload.sbhfIstGleis  = g_sbhf->istGleis();

    // ---------------------------
    // SBhf-Weichen (W12–W15)
    // ---------------------------
    uint16_t istBits  = 0;
    uint16_t sollBits = 0;

    for (uint8_t i = 0; i < MEGA2_MAX_WEICHEN; i++) {
        if (g_weichen[i]->istAbzweig())
            istBits |= (1u << i);

        if (g_weichen[i]->ziel == ABBIEGEN)
            sollBits |= (1u << i);
    }

    g_payload.weichenIstBits  = istBits;
    g_payload.weichenSollBits = sollBits;

    // ---------------------------
    // Trafos
    // ---------------------------
    g_payload.trafoOben_mV  = (uint16_t)(g_trafoOben.rms()  * 100.0f);
    g_payload.trafoUnten_mV = (uint16_t)(g_trafoUnten.rms() * 100.0f);

    // ---------------------------
    // Fehler / PowerState
    // ---------------------------
    bool overcurrent =
        g_stromBlock1.overThreshold() ||
        g_stromBlock2.overThreshold() ||
        g_stromBlock3.overThreshold() ||
        g_stromBlock4.overThreshold() ||
        g_stromBlock5.overThreshold() ||
        g_stromBlock6.overThreshold() ||
        g_stromSBhf1.overThreshold()  ||
        g_stromSBhf2.overThreshold()  ||
        g_stromSBhf3.overThreshold();

    g_payload.errorFlags = overcurrent ? ERR_OVERCURRENT : ERR_NONE;
    g_payload.warnFlags  = WARN_NONE;
    g_payload.powerState = g_power.state();

    // Mega ist READY
    g_payload.statusFlags |= (STATUS_FLAG_READY | STATUS_FLAG_SNAPSHOT_COMPLETE);

    // ---------------------------
    // Change Detection
    // ---------------------------
    bool changed = false;

    if (g_lastBlockBits       != blockBits)   { changed = true; g_lastBlockBits       = blockBits; }
    if (g_lastKontaktMainBits != mainBits)    { changed = true; g_lastKontaktMainBits = mainBits; }
    if (g_lastBhf1Bits        != bhf1Bits)    { changed = true; g_lastBhf1Bits        = bhf1Bits; }
    if (g_lastBhf2Bits        != bhf2Bits)    { changed = true; g_lastBhf2Bits        = bhf2Bits; }
    if (g_lastSBhfBits        != sbBits)      { changed = true; g_lastSBhfBits        = sbBits; }
    if (g_lastWeichenIstBits  != istBits)     { changed = true; g_lastWeichenIstBits  = istBits; }
    if (g_lastWeichenSollBits != sollBits)    { changed = true; g_lastWeichenSollBits = sollBits; }

    if (!g_payloadInitialized) {
        changed = true;
        g_payloadInitialized = true;
    }

    if (changed) {
        g_payload.updateCounter++;
        g_payloadDirty = true;
    }

    // ---------------------------
    // I2C Kommunikation
    // ---------------------------
    megaI2C_update();
}
