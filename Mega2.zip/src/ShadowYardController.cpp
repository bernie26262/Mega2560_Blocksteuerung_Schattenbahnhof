#include "ShadowYardController.h"

ShadowYardController::ShadowYardController(
    Block** blocks,
    Weiche** weichen,
    BlockController* controller,
    PowerControlPins* power,
    SensorKontakt* nothaltKontakt
)
: m_blocks(blocks),
  m_weichen(weichen),
  m_ctrl(controller),
  m_power(power),
  m_nothalt(nothaltKontakt)
{
}

void ShadowYardController::begin()
{
    // Später: Automatik-Modi, Initialzustände
}

void ShadowYardController::update(uint32_t now)
{
    // 1. Nothalt prüfen
    if (m_nothalt && m_nothalt->isOccupied())
    {
        m_power->trafosOff();
        return;
    }

    // 2. Placeholder – spätere komplexe Logik kommt hier
    (void)now;
}
